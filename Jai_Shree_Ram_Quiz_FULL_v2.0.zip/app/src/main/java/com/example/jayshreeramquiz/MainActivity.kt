package com.example.jayshreeramquiz

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Question(val id: Long=0, val quizId: Long=0, val pos:Int=0, var q:String="", var a:String="", var b:String="", var c:String="", var d:String="", var ans:String="A")
data class Quiz(val id:Long=0, var name:String="", var category:String="", var created:Long=0)

class DB(ctx: Context): android.database.sqlite.SQLiteOpenHelper(ctx, "quiz.db", null, 1) {
    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL("CREATE TABLE quizzes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,created INTEGER)")
        db.execSQL("CREATE TABLE questions(id INTEGER PRIMARY KEY AUTOINCREMENT,quiz_id INTEGER,pos INTEGER,q TEXT,a TEXT,b TEXT,c TEXT,d TEXT,ans TEXT)")
    }
    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, old:Int, new:Int) {}
    fun quizzes(): List<Quiz> {
        val out=mutableListOf<Quiz>(); readableDatabase.rawQuery("SELECT * FROM quizzes ORDER BY id DESC",null).use { c ->
            while(c.moveToNext()) out.add(Quiz(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3)))
        }; return out
    }
    fun getQuiz(id:Long): Quiz? {
        readableDatabase.rawQuery("SELECT * FROM quizzes WHERE id=?",arrayOf(id.toString())).use { c ->
            return if(c.moveToFirst()) Quiz(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3)) else null
        }
    }
    fun questions(id:Long): MutableList<Question> {
        val out=mutableListOf<Question>(); readableDatabase.rawQuery("SELECT * FROM questions WHERE quiz_id=? ORDER BY pos",arrayOf(id.toString())).use { c ->
            while(c.moveToNext()) out.add(Question(c.getLong(0),c.getLong(1),c.getInt(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8)))
        }; return out
    }
    fun saveQuiz(name:String,cat:String, qs:List<Question>, editId:Long=0):Long {
        val db=writableDatabase; db.beginTransaction()
        try {
            val id = if(editId==0L) {
                val v=android.content.ContentValues(); v.put("name",name); v.put("category",cat); v.put("created",System.currentTimeMillis())
                db.insert("quizzes",null,v)
            } else {
                val v=android.content.ContentValues(); v.put("name",name); v.put("category",cat); db.update("quizzes",v,"id=?",arrayOf(editId.toString())); editId
            }
            if(id>0) {
                if(editId!=0L) db.delete("questions","quiz_id=?",arrayOf(id.toString()))
                qs.forEachIndexed { i,x ->
                    val v=android.content.ContentValues(); v.put("quiz_id",id); v.put("pos",i); v.put("q",x.q); v.put("a",x.a); v.put("b",x.b); v.put("c",x.c); v.put("d",x.d); v.put("ans",x.ans.uppercase())
                    db.insert("questions",null,v)
                }
            }
            db.setTransactionSuccessful(); return id
        } finally { db.endTransaction() }
    }
    fun deleteQuiz(id:Long) { writableDatabase.delete("questions","quiz_id=?",arrayOf(id.toString())); writableDatabase.delete("quizzes","id=?",arrayOf(id.toString())) }
}

class MainActivity: Activity() {
    lateinit var db:DB
    lateinit var box:LinearLayout
    var currentQuizId=0L
    var editingQuestions=mutableListOf<Question>()
    var parsed=mutableListOf<Question>()
    var quizQs=mutableListOf<Question>()
    var quizIndex=0
    var userAnswers=mutableMapOf<Int,String>()
    var timer:CountDownTimer?=null
    var timerSeconds=0L

    override fun onCreate(b:Bundle?) { super.onCreate(b); db=DB(this); home() }
    fun base(title:String):LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(18,18,18,18)
        val bar=LinearLayout(this); bar.orientation=LinearLayout.HORIZONTAL
        val tv=TextView(this); tv.text=title; tv.textSize=24f; tv.setTextColor(Color.WHITE); tv.setPadding(16,12,8,12)
        bar.setBackgroundColor(Color.rgb(21,101,192)); bar.addView(tv,LinearLayout.LayoutParams(0,wrap(),1f))
        root.addView(bar); box=root; return root
    }
    fun wrap()=LinearLayout.LayoutParams.WRAP_CONTENT
    fun btn(t:String, f:()->Unit):Button { val b=Button(this); b.text=t; b.setOnClickListener{f()}; return b }
    fun text(t:String, size:Float=16f):TextView { val v=TextView(this); v.text=t; v.textSize=size; v.setPadding(6,10,6,10); return v }
    fun field(hint:String, value:String=""):EditText { val e=EditText(this); e.hint=hint; e.setText(value); e.textSize=17f; return e }
    fun scroll(content:View):ScrollView { val s=ScrollView(this); s.addView(content); return s }

    fun home() {
        timer?.cancel(); val r=base("જય શ્રી રામ ક્વિઝ"); setContentView(r)
        r.addView(text("📚 તમારી ક્વિઝ — સંપૂર્ણ Offline",18f))
        r.addView(btn("➕ નવી ક્વિઝ બનાવો"){editor(0)})
        r.addView(btn("📥 ક્વિઝ Import કરો"){importQuiz()})
        val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL; r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f))
        db.quizzes().forEach { q ->
            val card=LinearLayout(this); card.orientation=LinearLayout.VERTICAL; card.setPadding(8,12,8,12)
            card.addView(text("📖 ${q.name}",19f)); if(q.category.isNotBlank()) card.addView(text("કેટેગરી: ${q.category}",14f))
            val qs=db.questions(q.id); card.addView(text("પ્રશ્નો: ${qs.size}",14f))
            val row=LinearLayout(this)
            row.addView(btn("▶ શરૂ"){startQuiz(q.id)},LinearLayout.LayoutParams(0,wrap(),1f))
            row.addView(btn("✏ Edit"){editor(q.id)},LinearLayout.LayoutParams(0,wrap(),1f))
            row.addView(btn("📤 Share"){shareQuiz(q.id)},LinearLayout.LayoutParams(0,wrap(),1f))
            row.addView(btn("🗑 Delete"){confirmDelete(q.id)},LinearLayout.LayoutParams(0,wrap(),1f))
            card.addView(row); list.addView(card)
        }
    }

    fun editor(id:Long) {
        currentQuizId=id; parsed.clear(); val old=if(id>0) db.getQuiz(id) else null
        editingQuestions=if(id>0) db.questions(id) else mutableListOf()
        val r=base(if(id==0L)"નવી ક્વિઝ" else "ક્વિઝ Edit"); setContentView(r)
        val name=field("ક્વિઝનું નામ",old?.name?:""); val cat=field("કેટેગરી",old?.category?:"")
        r.addView(name); r.addView(cat)
        r.addView(text("એકસાથે 10 / 50 / 100 પ્રશ્નો Paste કરો. A/B/C/D એક જ લાઇનમાં હોય તો પણ ચાલશે.",15f))
        val paste=EditText(this); paste.hint="""1. હડપ્પા નામના સ્થળ ની શોધ કોણે કરી ?
A. સર વિલિયમ જેમ્સ  B. દયારામ સાહની  C. રખાલદાસ બેનરજી  D. વાસ્કો દ ગામા
Ans :- B. દયારામ સાહની"""; paste.minLines=10; paste.gravity=Gravity.TOP; paste.textSize=16f
        r.addView(scroll(paste),LinearLayout.LayoutParams(-1,0,1f))
        if(editingQuestions.isNotEmpty()) r.addView(text("આ ક્વિઝમાં ${editingQuestions.size} પ્રશ્નો પહેલેથી છે. નીચે Save/Edit Questions વિકલ્પ છે."))
        val row=LinearLayout(this)
        row.addView(btn("🔎 Parse / Preview"){ parsed=parseQuestions(paste.text.toString()); if(parsed.isEmpty()) toast("પ્રશ્ન મળ્યા નથી. Format ચેક કરો."); else preview(name.text.toString(),cat.text.toString())},LinearLayout.LayoutParams(0,wrap(),1f))
        row.addView(btn("💾 Existing Save"){ if(id>0){db.saveQuiz(name.text.toString(),cat.text.toString(),editingQuestions,id); toast("Save થયું"); home()} else toast("પહેલા પ્રશ્નો Parse કરો")},LinearLayout.LayoutParams(0,wrap(),1f))
        r.addView(row)
        if(id>0) r.addView(btn("📝 Existing Questions Edit"){questionManager(name.text.toString(),cat.text.toString())})
        r.addView(btn("← પાછા"){home()})
    }

    fun parseQuestions(raw:String):MutableList<Question> {
        val out=mutableListOf<Question>()
        val normalized=raw.replace("\r","").replace("Ans.:-","Ans :-").replace("Ans:","Ans :-").replace("Answer:","Ans :-")
        val starts=Regex("(?m)(?=^\\s*\\d+\\s*[\\.)])").split(normalized).filter{it.trim().isNotEmpty()}
        for(block0 in starts) {
            var block=block0.trim()
            block=block.replace(Regex("^\\d+\\s*[\\.)]\\s*"),"").trim()
            val am=Regex("(?is)\\bAns\\s*[-–—:]*\\s*([ABCD])\\s*(?:\\.|\\)|:)?").find(block) ?: continue
            val ans=am.groupValues[1].uppercase()
            val before=block.substring(0,am.range.first).trim()
            val om=Regex("(?is)(?:^|\\n)\\s*A\\s*[\\.)]\\s*(.*?)\\s+B\\s*[\\.)]\\s*(.*?)\\s+C\\s*[\\.)]\\s*(.*?)\\s+D\\s*[\\.)]\\s*(.*)$").find(before)
                ?: Regex("(?is)A\\s*[\\.)]\\s*(.*?)\\s+B\\s*[\\.)]\\s*(.*?)\\s+C\\s*[\\.)]\\s*(.*?)\\s+D\\s*[\\.)]\\s*(.*)$").find(before)
            if(om!=null) {
                val q=before.substring(0,om.range.first).trim().trimEnd(':','-')
                val a=om.groupValues[1].trim(); val bb=om.groupValues[2].trim(); val c=om.groupValues[3].trim(); val d=om.groupValues[4].trim()
                if(q.isNotBlank() && a.isNotBlank() && bb.isNotBlank() && c.isNotBlank() && d.isNotBlank()) out.add(Question(pos=out.size,q=q,a=a,b=bb,c=c,d=d,ans=ans))
            }
        }
        return out
    }

    fun preview(name:String,cat:String) {
        val r=base("Preview — ${parsed.size} પ્રશ્નો"); setContentView(r)
        r.addView(text("ક્વિઝ: $name\nકેટેગરી: $cat",18f))
        val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL
        parsed.forEachIndexed { i,q ->
            val card=LinearLayout(this); card.orientation=LinearLayout.VERTICAL
            card.addView(text("${i+1}. ${q.q}",17f)); card.addView(text("A. ${q.a}    B. ${q.b}    C. ${q.c}    D. ${q.d}",15f)); card.addView(text("✔ સાચો જવાબ: ${q.ans}",15f))
            card.addView(btn("✏ આ પ્રશ્ન Edit"){editOne(i, name,cat)})
            list.addView(card)
        }
        r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f))
        r.addView(btn("💾 આખી ક્વિઝ Save કરો"){db.saveQuiz(name,cat,parsed); toast("ક્વિઝ Save થઈ ગઈ"); home()})
        r.addView(btn("← પાછા"){editor(currentQuizId)})
    }

    fun editOne(i:Int,name:String,cat:String) {
        val q=parsed[i]; val r=base("પ્રશ્ન ${i+1} Edit"); setContentView(r)
        val qf=field("પ્રશ્ન",q.q); val a=field("A",q.a); val b=field("B",q.b); val c=field("C",q.c); val d=field("D",q.d); val ans=field("સાચો જવાબ A/B/C/D",q.ans)
        listOf(qf,a,b,c,d,ans).forEach{r.addView(it)}
        r.addView(btn("💾 Save"){q.q=qf.text.toString();q.a=a.text.toString();q.b=b.text.toString();q.c=c.text.toString();q.d=d.text.toString();q.ans=ans.text.toString().trim().uppercase().take(1);preview(name,cat)})
        r.addView(btn("← પાછા"){preview(name,cat)})
    }

    fun questionManager(name:String,cat:String) {
        val r=base("Questions Edit"); setContentView(r)
        val list=LinearLayout(this); list.orientation=LinearLayout.VERTICAL
        editingQuestions.forEachIndexed { i,q ->
            val b=btn("${i+1}. ${q.q.take(55)}"){editExisting(i,name,cat)}
            list.addView(b)
        }
        r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f))
        r.addView(btn("➕ નવો પ્રશ્ન"){editingQuestions.add(Question(pos=editingQuestions.size)); editExisting(editingQuestions.lastIndex,name,cat)})
        r.addView(btn("💾 Save"){db.saveQuiz(name,cat,editingQuestions,currentQuizId);toast("Save થયું");home()})
        r.addView(btn("← પાછા"){editor(currentQuizId)})
    }
    fun editExisting(i:Int,name:String,cat:String) {
        val q=editingQuestions[i]; val r=base("પ્રશ્ન Edit");setContentView(r)
        val qf=field("પ્રશ્ન",q.q);val a=field("A",q.a);val b=field("B",q.b);val c=field("C",q.c);val d=field("D",q.d);val ans=field("સાચો જવાબ",q.ans)
        listOf(qf,a,b,c,d,ans).forEach{r.addView(it)}
        r.addView(btn("💾 Save"){q.q=qf.text.toString();q.a=a.text.toString();q.b=b.text.toString();q.c=c.text.toString();q.d=d.text.toString();q.ans=ans.text.toString().trim().uppercase().take(1);questionManager(name,cat)})
        r.addView(btn("🗑 આ પ્રશ્ન Delete"){editingQuestions.removeAt(i);questionManager(name,cat)})
    }

    fun startQuiz(id:Long) {
        quizQs=db.questions(id); currentQuizId=id; if(quizQs.isEmpty()){toast("આ ક્વિઝમાં પ્રશ્નો નથી");return}
        val r=base("Quiz Start");setContentView(r); val q=db.getQuiz(id)!!
        r.addView(text("📖 ${q.name}\nકુલ પ્રશ્નો: ${quizQs.size}",20f))
        val timerChoice=Spinner(this); timerChoice.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Timer બંધ","10 મિનિટ","20 મિનિટ","30 મિનિટ"))
        r.addView(text("⏱ Optional Timer",17f));r.addView(timerChoice)
        r.addView(btn("▶ Quiz શરૂ કરો"){timerSeconds=when(timerChoice.selectedItemPosition){1->600L;2->1200L;3->1800L;else->0L};userAnswers.clear();quizIndex=0;quizPlay()})
        r.addView(btn("← પાછા"){home()})
    }

    fun quizPlay() {
        timer?.cancel(); val r=base("પ્રશ્ન ${quizIndex+1}/${quizQs.size}");setContentView(r)
        if(timerSeconds>0 && quizIndex==0){ timer=object:CountDownTimer(timerSeconds*1000,1000){override fun onTick(ms:Long){ } override fun onFinish(){toast("Timer પૂર્ણ");result()}}.start() }
        val q=quizQs[quizIndex]; r.addView(text(q.q,21f))
        val ans= userAnswers[quizIndex]
        val buttons=mutableListOf<Button>()
        listOf("A" to q.a,"B" to q.b,"C" to q.c,"D" to q.d).forEach { pair ->
            val b=btn("${pair.first}. ${pair.second}"){ if(!userAnswers.containsKey(quizIndex)){userAnswers[quizIndex]=pair.first; showFeedback(buttons,q,pair.first)} }
            buttons.add(b);r.addView(b)
        }
        if(ans!=null) showFeedback(buttons,q,ans)
        val nav=LinearLayout(this)
        nav.addView(btn("⬅ Previous"){if(quizIndex>0){quizIndex--;quizPlay()}},LinearLayout.LayoutParams(0,wrap(),1f))
        nav.addView(btn("Skip ➡"){if(quizIndex<quizQs.lastIndex){quizIndex++;quizPlay()}else result()},LinearLayout.LayoutParams(0,wrap(),1f))
        r.addView(nav)
        r.addView(btn(if(quizIndex==quizQs.lastIndex)"🏁 Result":"Next ➡"){if(quizIndex<quizQs.lastIndex){quizIndex++;quizPlay()}else result()})
        r.addView(btn("🏠 Quiz છોડો"){timer?.cancel();home()})
    }
    fun showFeedback(buttons:List<Button>,q:Question,selected:String) {
        buttons.forEachIndexed { i,b ->
            val letter="ABCD"[i].toString()
            if(letter==q.ans) b.setBackgroundColor(Color.rgb(165,220,165))
            if(letter==selected && selected!=q.ans) b.setBackgroundColor(Color.rgb(245,150,150))
        }
        if(selected!=q.ans) Toast.makeText(this,"❌ ખોટો જવાબ — સાચો જવાબ ${q.ans}",Toast.LENGTH_SHORT).show()
        else Toast.makeText(this,"✅ સાચો જવાબ",Toast.LENGTH_SHORT).show()
    }

    fun result() {
        timer?.cancel(); val total=quizQs.size;var correct=0;var wrong=0
        quizQs.forEachIndexed{i,q->val a=userAnswers[i];if(a==q.ans)correct++ else if(a!=null)wrong++}
        val skip=total-correct-wrong;val pct=if(total==0)0 else correct*100/total
        val r=base("પરિણામ");setContentView(r)
        r.addView(text("🏆 Quiz પૂર્ણ",25f));r.addView(text("કુલ પ્રશ્નો: $total\nસાચા: $correct\nખોટા: $wrong\nSkip: $skip\nટકા: $pct%",20f))
        r.addView(btn("📋 Detailed Review"){review()});r.addView(btn("🔄 ફરીથી Quiz"){startQuiz(currentQuizId)});r.addView(btn("🏠 Home"){home()})
    }
    fun review() {
        val r=base("Answer Review");setContentView(r);val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL
        quizQs.forEachIndexed{i,q->
            val ua=userAnswers[i]?:"Skip";val ok=ua==q.ans
            list.addView(text("${i+1}. ${q.q}\nતમારો જવાબ: $ua\nસાચો જવાબ: ${q.ans}\n${if(ok)"✅ સાચું" else "❌ ખોટું/Skip"}",16f))
        };r.addView(scroll(list),LinearLayout.LayoutParams(-1,0,1f));r.addView(btn("🏠 Home"){home()})
    }

    fun exportJson(id:Long):File {
        val q=db.getQuiz(id)!!; val arr=JSONArray()
        db.questions(id).forEach{x->arr.put(JSONObject().put("question",x.q).put("A",x.a).put("B",x.b).put("C",x.c).put("D",x.d).put("answer",x.ans))}
        return File(cacheDir,"${q.name.replace(Regex("[^A-Za-z0-9_\\-]"),"_")}.quiz").also{it.writeText(JSONObject().put("name",q.name).put("category",q.category).put("questions",arr).toString(2))}
    }
    fun shareQuiz(id:Long) {
        val f=exportJson(id);val uri=FileProvider.getUriForFile(this,"${packageName}.fileprovider",f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/octet-stream";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"ક્વિઝ Share કરો"))
    }
    fun importQuiz() { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},99) }
    override fun onActivityResult(req:Int,res:Int,data:Intent?) { super.onActivityResult(req,res,data);if(req==99&&res==RESULT_OK&&data?.data!=null) try{
        val o=JSONObject(contentResolver.openInputStream(data.data!!)?.bufferedReader().use{it?.readText()?:""})
        val arr=o.getJSONArray("questions");val qs=mutableListOf<Question>();for(i in 0 until arr.length()){val x=arr.getJSONObject(i);qs.add(Question(pos=i,q=x.getString("question"),a=x.getString("A"),b=x.getString("B"),c=x.getString("C"),d=x.getString("D"),ans=x.getString("answer")))}
        db.saveQuiz(o.optString("name","Imported Quiz"),o.optString("category",""),qs);toast("Import સફળ");home()
    }catch(e:Exception){toast("Import file ખોટી છે")} }
    fun confirmDelete(id:Long){AlertDialog.Builder(this).setTitle("Delete?").setMessage("આખી ક્વિઝ અને તેના પ્રશ્નો Delete થશે.").setNegativeButton("રદ",null).setPositiveButton("Delete"){_,_->db.deleteQuiz(id);home()}.show()}
    fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
