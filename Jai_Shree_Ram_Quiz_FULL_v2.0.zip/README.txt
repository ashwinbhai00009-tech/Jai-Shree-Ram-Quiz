જય શ્રી રામ ક્વિઝ - Full Version 2.0
Features:
- Offline SQLite database
- Unlimited quizzes/questions
- Bulk parser for Gujarati questions
- Supports A/B/C/D on one line or separate lines
- Correct answer parser
- Quiz play with instant feedback
- Previous/Next/Skip
- Optional whole-quiz timer
- Result + detailed review
- Edit/add/delete questions
- Export/import .quiz JSON files
- Share exported quiz through Android share sheet/WhatsApp
- No internet required
